/**
 * CẤU HÌNH — file duy nhất cần sửa khi dựng lại demo.
 * Xem HUONG-DAN.md Bước 5, và HUONG-DAN-GITHUB-ORG.md cho phần GitHub.
 */

/** Dán từ Firebase Console → Project settings → Your apps → biểu tượng `</>`. */
export const firebaseConfig = {
  apiKey: "AIzaSyBK_zUfBGuRsUpFSJXG06bTdya3XpS83rA",
  authDomain: "test-d3c8c.firebaseapp.com",
  projectId: "test-d3c8c",
  storageBucket: "test-d3c8c.firebasestorage.app",
  messagingSenderId: "972587571884",
  appId: "1:972587571884:web:6e7cbc0a876ff798bddd09",
};

/**
 * Email cá nhân được khai báo trước để MÔ PHỎNG giảng viên, và để dọn ghi chú
 * không phù hợp lúc demo. Đây chỉ là cấu hình HIỂN THỊ — quyền thật nằm ở
 * hàm demoLecturerEmails() trong firestore.rules. Đổi ở đây thì sửa y hệt bên đó.
 */
export const DEMO_LECTURER_EMAILS = ["buiquanghuy200527@gmail.com"];

/** Tên miền email của trường. Tầng 2 trong thứ tự xét vai trò. */
export const STUDENT_DOMAIN = "@student.tdtu.edu.vn";
export const LECTURER_DOMAIN = "@tdtu.edu.vn";

/**
 * Tổ chức GitHub dùng để demo "tổ chức khai vai trò".
 * Để "" thì bỏ qua phần đọc team. Tạo miễn phí: https://github.com/organizations/plan
 */
export const GITHUB_ORG = "";

/**
 * Bản đồ team slug → vai trò. Slug là phần trong URL của team, không phải tên
 * hiển thị: team tên "Sinh viên" có thể ra slug "sinh-vien".
 */
export const GITHUB_TEAM_MAP = {
  students: "student",
  lecturers: "lecturer",
};

/** Số ghi chú mới nhất hiển thị trên trang. */
export const NOTES_LIMIT = 50;
