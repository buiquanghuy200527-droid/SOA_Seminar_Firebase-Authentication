/** PHA 1 — Xác thực: tab, form đăng ký/đăng nhập, nút provider, xác minh email. */
import {
  auth, signOut,
  createUserWithEmailAndPassword, signInWithEmailAndPassword,
  sendEmailVerification, sendPasswordResetEmail, updateProfile,
  signInWithPopup, getAdditionalUserInfo, GithubAuthProvider,
} from "./firebase.js";
import { $, show } from "./dom.js";
import { errText } from "./errors.js";
import { state, rerender } from "./state.js";
import { OAUTH_PROVIDERS, fetchGithubTeams } from "./providers.js";
import { saveDemoRole } from "./roles.js";

export function selectTab(name) {
  document.querySelectorAll(".tab")
    .forEach((x) => x.classList.toggle("active", x.dataset.tab === name));
  $("form-login").classList.toggle("hidden", name !== "login");
  $("form-register").classList.toggle("hidden", name !== "register");
  show($("auth-msg"), "");
}

export function initAuthUI() {
  document.querySelectorAll(".tab").forEach((t) =>
    t.addEventListener("click", () => selectTab(t.dataset.tab)));

  // Đăng ký bằng Email/Password → gửi email xác minh
  $("form-register").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    try {
      const cred = await createUserWithEmailAndPassword(
        auth, $("reg-email").value.trim(), $("reg-password").value);
      await updateProfile(cred.user, { displayName: $("reg-name").value.trim() });
      await sendEmailVerification(cred.user);
      rerender(cred.user); // để hiện ngay tên vừa đặt
    } catch (e) { show($("auth-msg"), errText(e), "error"); }
  });

  // Đăng nhập bằng Email/Password
  $("form-login").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    try {
      await signInWithEmailAndPassword(
        auth, $("login-email").value.trim(), $("login-password").value);
    } catch (e) { show($("auth-msg"), errText(e), "error"); }
  });

  // Quên mật khẩu
  $("btn-forgot").addEventListener("click", async () => {
    const email = $("login-email").value.trim();
    if (!email) return show($("auth-msg"), "Nhập email ở ô phía trên trước.", "error");
    try {
      await sendPasswordResetEmail(auth, email);
      show($("auth-msg"), "Đã gửi email đặt lại mật khẩu (nếu email này tồn tại).", "ok");
    } catch (e) { show($("auth-msg"), errText(e), "error"); }
  });

  // Đăng nhập bằng provider bên ngoài
  for (const [btnId, makeProvider] of Object.entries(OAUTH_PROVIDERS)) {
    $(btnId).addEventListener("click", async () => {
      try {
        const result = await signInWithPopup(auth, makeProvider());
        // Claim thô CHỈ có ở kết quả đăng nhập, không lấy lại được sau đó.
        state.providerClaims = getAdditionalUserInfo(result)?.profile || null;
        state.providerTeams = btnId === "btn-github"
          ? await fetchGithubTeams(GithubAuthProvider.credentialFromResult(result)?.accessToken)
          : [];
        rerender(auth.currentUser);
      } catch (e) { show($("auth-msg"), errText(e), "error"); }
    });
  }

  $("btn-logout").addEventListener("click", () => signOut(auth));

  // Xác minh email xong: tải lại user VÀ làm mới token — token cũ vẫn ghi
  // email_verified=false nên Security Rules sẽ còn chặn.
  $("btn-verified").addEventListener("click", async () => {
    await auth.currentUser.reload();
    await auth.currentUser.getIdToken(true);
    rerender(auth.currentUser);
  });

  $("btn-resend").addEventListener("click", async () => {
    try {
      await sendEmailVerification(auth.currentUser);
      alert("Đã gửi lại email xác minh.");
    } catch (e) { alert(errText(e)); }
  });

  // Chế độ demo: chọn / đổi vai trò
  const pick = (role, msgId) =>
    saveDemoRole(role).catch((e) => show($(msgId), errText(e), "error"));

  $("btn-pick-student").addEventListener("click", () => pick("student", "role-msg"));
  $("btn-pick-lecturer").addEventListener("click", () => pick("lecturer", "role-msg"));
  $("btn-switch-role").addEventListener("click", () =>
    pick(state.currentRole === "student" ? "lecturer" : "student", "demo-msg"));
}
