# Firebase Authentication — Demo seminar Nhóm 12

Ứng dụng web minh hoạ **xác thực** (Email/Password · Google · GitHub) và **phân quyền**
(Firestore Security Rules), kèm phần "tổ chức khai vai trò" bằng GitHub Organization teams.

Không có bước build. Mã nguồn là ES module chạy thẳng trên trình duyệt.

---

## Cấu trúc

```
app/                        ← thư mục DUY NHẤT cần deploy lên Netlify
  index.html                  markup, không có CSS/JS nội tuyến
  css/
    styles.css                toàn bộ style
  js/
    config.js                 ★ file duy nhất cần sửa khi dựng lại demo
    firebase.js               khởi tạo SDK, gom mọi import từ CDN về một chỗ
    dom.js                    tiện ích DOM ($, show, fatal)
    state.js                  trạng thái dùng chung + móc rerender (tránh phụ thuộc vòng)
    errors.js                 mã lỗi Firebase → câu tiếng Việt
    roles.js                  xét vai trò (bản sao để hiển thị của firestore.rules)
    providers.js              provider OAuth + đọc team GitHub
    auth-ui.js                PHA 1 — form, tab, nút đăng nhập, xác minh email
    notes.js                  PHA 2 — danh sách ghi chú trên Firestore
    jwt.js                    xem / gửi / sửa ID Token
    idp-card.js               thẻ "tổ chức khai gì về bạn"
    app.js                    điểm vào: nối mọi thứ, hàm render()

firestore.rules             ← dán vào Firebase Console, KHÔNG deploy cùng app
*.md, *.pdf                 tài liệu
```

## Đồ thị phụ thuộc

```
                 config.js
                /    |     \
        firebase.js  |   providers.js
         /   |   \   |      |
   roles.js  |  notes.js    |
       \     |    /         |
        \  jwt.js      idp-card.js
         \   |   /         /
          auth-ui.js      /
                \        /
                 app.js  ← điểm vào duy nhất
```

Không có phụ thuộc vòng. `app.js` sở hữu hàm `render()` và đăng ký nó vào `state.js`;
các module khác gọi `rerender()` thay vì import ngược lại `app.js`.

## Chạy tại máy

ES module **không chạy** khi mở file bằng double-click (`file://` bị chặn CORS).
Phải phục vụ qua HTTP:

```bash
cd app
python3 -m http.server 8000
# mở http://localhost:8000
```

Nhớ thêm `localhost` vào Firebase → Authentication → Settings → Authorized domains
(mặc định đã có sẵn).

## Dựng lại từ đầu

Xem `HUONG-DAN.md`. Tóm tắt: tạo project Firebase → bật Email/Password, Google, GitHub →
tạo Firestore → dán `firebaseConfig` vào `app/js/config.js` → Publish `firestore.rules` →
tạo collection `allowlist` → kéo thả thư mục `app/` lên Netlify.

Phần GitHub Organization (để thẻ IdP hiện `teams: lecturers`): xem `HUONG-DAN-GITHUB-ORG.md`.

## Vai trò đến từ đâu

Thứ tự xét, tầng trên thắng. `app/js/roles.js` và `firestore.rules` phải khớp nhau:

| # | Nguồn | Server có tin không |
|---|---|---|
| 1 | `allowlist` trong Firestore (admin cấp) | ✅ |
| 2 | Tên miền email của trường | ✅ |
| 3 | Chế độ demo tự chọn | ⚠️ chỉ là tiện ích demo |
| 4 | Team GitHub của tổ chức | ❌ chỉ hiển thị |

Tầng 4 nằm trong `providers.js` và `idp-card.js`, và **không xuất hiện ở đâu trong
`firestore.rules`** — đó là chủ ý, không phải thiếu sót. Lý do: với GitHub, vai trò không
nằm trong token, phải để trình duyệt gọi `api.github.com` mới lấy được, nên dữ liệu đó đi
qua tay client và không dùng để cấp quyền được.

## Tài liệu

| File | Nội dung |
|---|---|
| `HUONG-DAN.md` | Dựng demo từ đầu + kịch bản demo trên lớp |
| `HUONG-DAN-GITHUB-ORG.md` | Tạo GitHub Organization và teams |
| `TRA-LOI-CAU-HOI-PHAN-QUYEN.md` | Trả lời câu hỏi phân quyền của thầy |
| `KICH-BAN-THUYET-TRINH.md` | Lời thoại thuyết trình |
| `CHECKLIST-TRUOC-BUOI.md` | Việc cần làm trước buổi |
